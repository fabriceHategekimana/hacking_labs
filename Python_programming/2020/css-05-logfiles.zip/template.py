#!/usr/bin/env python3
import sys
import json
import argparse

def process_logs(access_file, forensics_file):
    with open(access_file, 'r') as access, open(forensics_file, 'r') as forensics:
        # TODO: Process forensics log file
        
        
        # Process access log file
        for l in access:
            try:
                # TODO: Process line of access.log file here
                # You can write your result to a file, or to stdout:
                obj = {'value': 123}
                print(json.dumps(obj))
            except Exception as e:
                print("Error {} on line {}".format(e, l), file=sys.stderr)
                sys.exit(1)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Process web application log files.')
    parser.add_argument('-a', '--access', help='the acces log file to parse', default='access.log')
    parser.add_argument('-f', '--forensics', help='the forensics log file to parse', default='forensics.json')

    args = parser.parse_args()

    process_logs(args.access, args.forensics)

