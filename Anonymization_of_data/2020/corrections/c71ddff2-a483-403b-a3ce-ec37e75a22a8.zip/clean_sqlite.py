#!/usr/bin/python3

import os
import sqlite3

if __name__ == '__main__':
    dbFilename = "customerdata.db"
    try:
        cwd = os.getcwd()
        conn = sqlite3.connect('{0}{1}{2}'.format(cwd, os.sep, dbFilename))
        c = conn.cursor()
        c.execute('''SELECT count(*) FROM customers;''')
        user_count = c.fetchall()[0][0]
        for i in range(user_count):
            idx = i + 1
            c.execute('''UPDATE `customers` SET `firstname`=\'{0}\' WHERE id='{1}';'''.format('firstname{0:05}'.format(idx),idx))
            c.execute('''UPDATE `customers` SET `lastname`=\'{0}\' WHERE id='{1}';'''.format('lastname{0:05}'.format(idx),idx))
            c.execute('''UPDATE `customers` SET `phone`=\'{0}\' WHERE id='{1}';'''.format('phone{0:05}'.format(idx),idx))
            c.execute('''UPDATE `customers` SET `email`=\'{0}\' WHERE id='{1}';'''.format('email{0:05}@example.org'.format(idx),idx))
            c.execute('''UPDATE `customers` SET `email`=\'{0}\' WHERE id='{1}';'''.format('email{0:05}@example.org'.format(idx),idx))
            c.execute('''UPDATE `customers` SET `cc_number`=\'{0}\' WHERE id='{1}';'''.format('cc_cumber{0:05}'.format(idx),idx))
        conn.commit()
        conn.close()
    except Exception as e:
        print('Type: {0}; Issue: {1}'.format(type(e), e))