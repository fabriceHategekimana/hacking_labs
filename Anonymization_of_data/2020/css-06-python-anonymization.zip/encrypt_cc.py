#!/usr/bin/python3

import os
import binascii
import sqlite3

def encrypt(val,s):
    x = 2<<7
    n = 0
    p = s
    p = [ord(x) for x in p]
    var = []
    while n < x:
        var.append(n)
        n += 1
    t = 0
    t_n = len(p)
    n = 0
    while n < x:
        t = t + var[n] + p[n % t_n]
        t %= x
        t_s = var[n]
        var[n] = var[t]
        var[t] = t_s
        n += 1
    t_n = len(val)
    p = 0
    q = 0
    t_t = []
    for n in range(t_n):
        t_t.append(n)
    n=0
    while n < t_n:
        p += 1
        p %= x
        q += var[p]
        q %= x
        t_s = var[p]
        var[p] = var[q]
        var[q] = t_s
        t_r = var[p] + var[q]
        t_r %= x
        t_r = var[t_r]
        t_t[n]=(t_r^ord(val[n]))
        n += 1
    return ''.join(['%02x'%x for x in t_t]) 

if __name__ == '__main__':
    dbFilename = "customerdata.db"
    encrypted_cc_numbers = []
    try:
        cwd = os.getcwd()
        conn = sqlite3.connect('{0}{1}{2}'.format(cwd, os.sep, dbFilename))
        c = conn.cursor()
        c.execute('''SELECT cc_number FROM customers;''')
        cc_numbers = c.fetchall()

        for cc in cc_numbers:
            encrypted_cc_numbers.append(encrypt(cc[0],'219203'))

        print(encrypted_cc_numbers)
        cnt = 1
        for cc in encrypted_cc_numbers:
            c.execute('''UPDATE `customers` SET `cc_number`=\'{0}\' WHERE id='{1}';'''.format(cc,cnt))
            cnt += 1
        conn.commit()
        conn.close()
    except Exception as e:
        print('Type: {0}; Issue: {1}'.format(type(e), e))